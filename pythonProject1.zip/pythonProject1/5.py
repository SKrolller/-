class Triangle:
    def __init__(self, side1, side2, side3):
        self.side1 = side1
        self.side2 = side2
        self.side3 = side3

    def get_triangle_type(self):
        if self.side1 == self.side2 == self.side3:
            return "Равносторонний"
        elif self.side1 == self.side2 or self.side1 == self.side3 or self.side2 == self.side3:
            return "Равнобедренный"
        else:
            return "Разносторонний"

    def calculate_area(self):
        # Используем формулу Герона для вычисления площади треугольника
        s = (self.side1 + self.side2 + self.side3) / 2
        area = (s * (s - self.side1) * (s - self.side2) * (s - self.side3)) ** 0.5
        return area


# пример использования
triangle1 = Triangle(3, 4, 5)
print(triangle1.get_triangle_type())
print(triangle1.calculate_area())
