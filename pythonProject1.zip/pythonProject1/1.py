class Student:
    def __init__(self, name, age, average_score):
        self.name = name
        self.age = age
        self.average_score = average_score

    def get_name(self):
        return self.name

    def set_name(self, name):
        self.name = name

    def get_age(self):
        return self.age

    def set_age(self, age):
        self.age = age

    def get_average_score(self):
        return self.average_score

    def set_average_score(self, average_score):
        self.average_score = average_score


# Пример использования
student1 = Student("Демидов", 16, 4.9)
print(student1.get_name())
