class BankAccount:
    def __init__(self, client_name, balance):
        self.client_name = client_name
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount

    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
        else:
            print("Insufficient funds")

    def get_balance(self):
        return self.balance


# Пример использования
account1 = BankAccount("Иванов", 1000)
account1.deposit(500)  # Пополнение счета
print(account1.get_balance())  #

